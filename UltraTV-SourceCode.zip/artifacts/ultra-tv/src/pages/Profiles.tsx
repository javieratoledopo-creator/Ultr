import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Profile } from "@/lib/firestore";
import { Plus, Edit2 } from "lucide-react";
import { useDeviceType } from "@/hooks/useDeviceType";

export default function Profiles() {
  const { user, userDoc, setActiveProfile } = useAuth();
  const [, setLocation] = useLocation();
  const [isEditing, setIsEditing] = useState(false);
  const { isTV } = useDeviceType();

  const handleSelectProfile = async (profile: Profile) => {
    if (isEditing) {
      setLocation(`/profile/edit/${profile.id}`);
      return;
    }
    
    if (user) {
      await updateDoc(doc(db, "users", user.uid), {
        activeProfileId: profile.id
      });
      setActiveProfile(profile);
      setLocation("/home");
    }
  };

  const handleAddProfile = () => {
    setLocation("/profile/new");
  };

  if (!userDoc) return <div className="min-h-screen bg-background" />;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center text-white relative">
      <h1 className={`${isTV ? "text-6xl" : "text-4xl md:text-5xl"} font-medium mb-12`}>
        {isEditing ? "¿Qué perfil deseas editar?" : "¿Quién está viendo ahora?"}
      </h1>

      <div className="flex flex-wrap justify-center gap-6 md:gap-8 lg:gap-12 max-w-5xl px-4">
        {userDoc.profiles.map((profile) => (
          <div key={profile.id} className="flex flex-col items-center group">
            <button 
              onClick={() => handleSelectProfile(profile)}
              className={`relative rounded-md overflow-hidden outline-none focus:ring-4 focus:ring-white transition-all duration-200
                ${isTV ? "w-48 h-48" : "w-28 h-28 md:w-36 md:h-36"}
                group-hover:border-2 group-hover:border-white
              `}
              data-tv-focusable="true"
            >
              <img 
                src={`/assets/avatar-${profile.avatarIndex + 1}.jpg`} 
                alt={profile.name} 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100"
              />
              
              {isEditing && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                  <Edit2 className="w-10 h-10 text-white" />
                </div>
              )}
            </button>
            <span className={`mt-4 text-gray-400 group-hover:text-white transition-colors ${isTV ? "text-2xl" : "text-base md:text-lg"}`}>
              {profile.name}
            </span>
          </div>
        ))}

        {userDoc.profiles.length < 5 && (
          <div className="flex flex-col items-center group">
            <button 
              onClick={handleAddProfile}
              className={`flex items-center justify-center rounded-md border-2 border-transparent group-hover:border-white group-hover:bg-white text-gray-400 group-hover:text-black transition-all duration-200 outline-none focus:ring-4 focus:ring-white focus:bg-white focus:text-black
                ${isTV ? "w-48 h-48" : "w-28 h-28 md:w-36 md:h-36"}
              `}
              data-tv-focusable="true"
            >
              <Plus className="w-16 h-16" />
            </button>
            <span className={`mt-4 text-gray-400 group-hover:text-white transition-colors ${isTV ? "text-2xl" : "text-base md:text-lg"}`}>
              Agregar Perfil
            </span>
          </div>
        )}
      </div>

      <div className="mt-16 md:mt-24">
        <button
          onClick={() => setIsEditing(!isEditing)}
          className={`border border-gray-500 text-gray-400 hover:text-white hover:border-white transition-colors tracking-widest uppercase outline-none focus:ring-2 focus:ring-white
            ${isTV ? "px-10 py-4 text-xl" : "px-6 py-2 text-sm"}
          `}
          data-tv-focusable="true"
        >
          {isEditing ? "Listo" : "Administrar Perfiles"}
        </button>
      </div>
    </div>
  );
}
