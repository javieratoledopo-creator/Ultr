import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Play, Plus, ThumbsUp, ChevronLeft } from "lucide-react";
import Navbar from "@/components/Navbar";
import ContentRow from "@/components/ContentRow";
import { tmdb } from "@/lib/tmdb";
import { useTVNavigation } from "@/hooks/useTVNavigation";
import { useDeviceType } from "@/hooks/useDeviceType";

interface ContentDetailProps {
  id: string;
}

export default function ContentDetail({ id }: ContentDetailProps) {
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [, setLocation] = useLocation();
  const { isTV } = useDeviceType();
  useTVNavigation();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const type = params.get('type') || 'movie';

    async function loadData() {
      try {
        const data = await tmdb.fetchDetails(Number(id), type as any);
        setContent(data);
      } finally {
        setLoading(false);
      }
    }
    
    window.scrollTo(0, 0);
    loadData();
  }, [id]);

  if (loading) return <div className="min-h-screen bg-black animate-pulse" />;
  if (!content) return <div className="min-h-screen bg-black text-white p-20">Contenido no encontrado.</div>;

  const title = content.title || content.name;
  const releaseDate = content.release_date || content.first_air_date;
  const year = releaseDate ? new Date(releaseDate).getFullYear() : '';
  const duration = content.runtime ? `${Math.floor(content.runtime / 60)}h ${content.runtime % 60}m` : (content.number_of_seasons ? `${content.number_of_seasons} Temporadas` : '');
  
  const type = content.name ? 'series' : 'movie';
  const similar = (content.similar?.results || []).map((i:any) => ({...i, type}));

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />

      {/* Hero Banner */}
      <div className="relative w-full h-[60vh] md:h-[80vh]">
        <div className="absolute inset-0">
          <img 
            src={`https://image.tmdb.org/t/p/original${content.backdrop_path}`} 
            alt={title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent"></div>
        </div>

        <div className="absolute top-24 left-4 md:left-12 z-20">
          <button 
            onClick={() => setLocation(-1)}
            className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
            data-tv-focusable="true"
          >
            <ChevronLeft className="w-6 h-6" /> Volver
          </button>
        </div>

        <div className={`absolute bottom-0 left-0 w-full p-6 md:p-12 ${isTV ? "pb-24 px-16" : "pb-12"} md:w-2/3 lg:w-1/2 z-10 flex flex-col justify-end h-full`}>
          <h1 className={`font-black text-white leading-tight mb-4 ${isTV ? "text-6xl" : "text-4xl md:text-5xl lg:text-6xl"}`}>
            {title}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-sm md:text-base font-semibold text-gray-300 mb-6">
            <span className="text-green-400 font-bold">{Math.round(content.vote_average * 10)}% Coincidencia</span>
            <span>{year}</span>
            <span className="border border-gray-500 px-1.5 py-0.5 rounded text-xs">4K</span>
            <span>{duration}</span>
          </div>

          <p className="text-gray-200 text-sm md:text-lg mb-8 line-clamp-4 drop-shadow-md">
            {content.overview}
          </p>

          <div className="flex items-center gap-4 mb-8">
            <Link href={`/player/${id}?type=${type}`}>
              <button 
                className={`bg-white text-black font-bold flex items-center justify-center gap-2 rounded hover:bg-gray-200 transition-colors outline-none focus:ring-4 focus:ring-primary
                  ${isTV ? "py-4 px-10 text-2xl" : "py-3 px-8 text-lg"}
                `}
                data-tv-focusable="true"
              >
                <Play className={isTV ? "w-8 h-8 fill-current" : "w-6 h-6 fill-current"} />
                Reproducir
              </button>
            </Link>
            
            <button 
              className={`bg-zinc-800/80 border border-gray-500 text-white rounded-full flex items-center justify-center hover:border-white transition-colors outline-none focus:ring-4 focus:ring-white
                ${isTV ? "w-16 h-16" : "w-12 h-12"}
              `}
              data-tv-focusable="true"
            >
              <Plus className={isTV ? "w-8 h-8" : "w-6 h-6"} />
            </button>

            <button 
              className={`bg-zinc-800/80 border border-gray-500 text-white rounded-full flex items-center justify-center hover:border-white transition-colors outline-none focus:ring-4 focus:ring-white
                ${isTV ? "w-16 h-16" : "w-12 h-12"}
              `}
              data-tv-focusable="true"
            >
              <ThumbsUp className={isTV ? "w-7 h-7" : "w-5 h-5"} />
            </button>
          </div>

          <div className="text-sm text-gray-400">
            <p className="mb-1"><span className="text-gray-500">Géneros:</span> {content.genres?.map((g:any)=>g.name).join(', ')}</p>
          </div>
        </div>
      </div>

      <div className="px-4 md:px-12 mt-12 md:mt-0 relative z-20">
        <ContentRow title="Similares" items={similar} />
      </div>
    </div>
  );
}
