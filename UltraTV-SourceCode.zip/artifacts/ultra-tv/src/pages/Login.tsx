import { useState } from "react";
import { useLocation } from "wouter";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth, db } from "@/lib/firebase";
import { doc, getDoc } from "firebase/firestore";
import { UserDoc } from "@/lib/firestore";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDocRef = doc(db, "users", userCredential.user.uid);
      const userDocSnap = await getDoc(userDocRef);

      if (userDocSnap.exists()) {
        const userData = userDocSnap.data() as UserDoc;
        
        if (!userData.active) {
          auth.signOut();
          toast({ variant: "destructive", title: "Cuenta Desactivada", description: "Por favor, contacta a tu proveedor." });
          setLoading(false);
          return;
        }

        if (userData.expiresAt && userData.expiresAt.toDate() < new Date()) {
          auth.signOut();
          toast({ variant: "destructive", title: "Suscripción Vencida", description: "Tu suscripción ha expirado." });
          setLoading(false);
          return;
        }

        if (userData.role === 'admin') setLocation("/admin");
        else if (userData.role === 'seller') setLocation("/seller");
        else setLocation("/profiles");
        
      } else {
        // First time admin login check (handled by AuthContext, so just redirect)
        if (email === "administrador@gmail.com") {
           setLocation("/admin");
        } else {
          toast({ variant: "destructive", title: "Error", description: "No se encontraron datos del usuario." });
        }
      }
    } catch (error: any) {
      toast({ variant: "destructive", title: "Error al iniciar sesión", description: "Correo o contraseña incorrectos." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col relative overflow-hidden">
      {/* Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-luminosity"
        style={{ backgroundImage: 'url(/assets/ultra-tv-banner.png)' }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/90"></div>
      </div>
      
      {/* Header */}
      <header className="relative z-10 px-6 py-6 md:px-12 md:py-8">
        <img src="/assets/ultra-tv-logo.png" alt="Ultra TV" className="h-10 md:h-12" />
      </header>

      {/* Login Form */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4">
        <div className="bg-black/70 p-10 md:p-16 rounded-xl w-full max-w-[450px] backdrop-blur-md border border-white/10 shadow-2xl">
          <h1 className="text-3xl font-bold text-white mb-8">Iniciar Sesión</h1>
          
          <form onSubmit={handleLogin} className="flex flex-col gap-6">
            <div className="relative">
              <Input
                type="email"
                placeholder="Correo o número de teléfono"
                className="bg-zinc-800/80 border-transparent text-white placeholder:text-gray-400 h-14 text-base focus-visible:ring-primary focus-visible:ring-offset-0 focus-visible:border-primary rounded-md"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="relative">
              <Input
                type="password"
                placeholder="Contraseña"
                className="bg-zinc-800/80 border-transparent text-white placeholder:text-gray-400 h-14 text-base focus-visible:ring-primary focus-visible:ring-offset-0 focus-visible:border-primary rounded-md"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-bold text-lg rounded-md mt-4 transition-colors"
              disabled={loading}
            >
              {loading ? "Iniciando..." : "Iniciar Sesión"}
            </Button>

            <div className="flex items-center justify-between text-sm text-gray-400 mt-2">
              <label className="flex items-center gap-2 cursor-pointer hover:text-gray-300">
                <input type="checkbox" className="w-4 h-4 rounded border-gray-600 bg-zinc-800 accent-primary" />
                Recuérdame
              </label>
              <a href="#" className="hover:text-gray-300">¿Necesitas ayuda?</a>
            </div>
          </form>

          <div className="mt-16 text-gray-400">
            <p>¿Primera vez en Ultra TV? <a href="#" className="text-white hover:underline">Suscríbete ahora.</a></p>
            <p className="mt-4 text-xs text-gray-500">
              Esta página está protegida por reCAPTCHA para comprobar que no eres un robot.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
