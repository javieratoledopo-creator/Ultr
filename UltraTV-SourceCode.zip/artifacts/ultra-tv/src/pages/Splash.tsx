import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

export default function Splash() {
  const [, setLocation] = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (loading) return;

    const timer = setTimeout(() => {
      if (user) {
        setLocation("/profiles");
      } else {
        setLocation("/login");
      }
    }, 2500);

    return () => clearTimeout(timer);
  }, [user, loading, setLocation]);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
      {/* Background Banner (dimmed) */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-30"
        style={{ backgroundImage: 'url(/assets/ultra-tv-banner.png)' }}
      >
        <div className="absolute inset-0 bg-black/60"></div>
      </div>
      
      {/* Logo container with scale animation */}
      <div className="relative z-10 animate-in zoom-in duration-1000">
        <img 
          src="/assets/ultra-tv-logo.png" 
          alt="Ultra TV" 
          className="w-64 md:w-96"
        />
        
        <div className="mt-12 flex justify-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    </div>
  );
}
