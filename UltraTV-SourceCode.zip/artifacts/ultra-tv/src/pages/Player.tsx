import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, Maximize, Settings, SkipForward, Play, Pause, Volume2, VolumeX } from "lucide-react";
import Hls from "hls.js";
import { useDeviceType } from "@/hooks/useDeviceType";
import { tmdb } from "@/lib/tmdb";

interface PlayerProps {
  id: string;
  type: string;
}

export default function Player({ id, type }: PlayerProps) {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<any>(null);
  const [, setLocation] = useLocation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const { isTV } = useDeviceType();

  // Stub stream URL for demo purposes.
  // In a real app, this comes from Firestore based on the TMDB ID.
  const streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";

  useEffect(() => {
    async function loadData() {
      const data = await tmdb.fetchDetails(Number(id), type as any);
      setContent(data);
      setLoading(false);
    }
    loadData();
  }, [id, type]);

  useEffect(() => {
    if (loading || !videoRef.current) return;

    const video = videoRef.current;

    if (Hls.isSupported() && streamUrl.endsWith('.m3u8')) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });
      hls.loadSource(streamUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(e => console.log("Autoplay prevented", e));
      });

      return () => {
        hls.destroy();
      };
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = streamUrl;
      video.addEventListener('loadedmetadata', () => {
        video.play().catch(e => console.log("Autoplay prevented", e));
      });
    } else {
      video.src = streamUrl;
    }
  }, [loading, streamUrl]);

  if (loading) {
    return <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
    </div>;
  }

  return (
    <div className="fixed inset-0 bg-black z-50 group">
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        autoPlay
        controls
      />
      
      {/* Top Controls Overlay (fade on idle in real app) */}
      <div className="absolute top-0 left-0 w-full p-6 bg-gradient-to-b from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-4">
        <button 
          onClick={() => setLocation(-1)}
          className="text-white hover:text-primary transition-colors"
          data-tv-focusable="true"
        >
          <ArrowLeft className={isTV ? "w-10 h-10" : "w-8 h-8"} />
        </button>
        <h2 className={`text-white font-bold ${isTV ? "text-3xl" : "text-xl"}`}>
          {content?.title || content?.name}
        </h2>
      </div>
    </div>
  );
}
