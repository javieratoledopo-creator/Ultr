import AdminLayout from "./AdminLayout";
import { Users, Film, PlayCircle, DollarSign } from "lucide-react";

export default function AdminDashboard() {
  const stats = [
    { name: "Total Usuarios", value: "1,248", icon: Users, color: "text-blue-500" },
    { name: "Películas", value: "8,432", icon: Film, color: "text-green-500" },
    { name: "Series", value: "1,154", icon: PlayCircle, color: "text-purple-500" },
    { name: "Ventas Mensuales", value: "$4,250", icon: DollarSign, color: "text-yellow-500" },
  ];

  return (
    <AdminLayout>
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map(stat => (
            <div key={stat.name} className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl flex items-center gap-4">
              <div className={`p-4 rounded-full bg-zinc-800 ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-gray-400">{stat.name}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
            <h3 className="text-lg font-bold mb-4">Últimos Usuarios Registrados</h3>
            <div className="space-y-4">
              {[1,2,3,4,5].map(i => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-zinc-800 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-sm font-bold">U{i}</div>
                    <div>
                      <p className="font-medium text-sm">usuario{i}@gmail.com</p>
                      <p className="text-xs text-gray-500">hace {i} horas</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 bg-green-500/20 text-green-500 text-xs rounded border border-green-500/20">Activo</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
            <h3 className="text-lg font-bold mb-4">Contenido Reciente</h3>
            <div className="space-y-4">
              <div className="text-gray-400 text-sm py-8 text-center border border-dashed border-zinc-800 rounded">
                No hay contenido agregado recientemente.
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
