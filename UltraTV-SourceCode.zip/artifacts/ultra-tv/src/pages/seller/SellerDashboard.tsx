import SellerLayout from "./SellerLayout";
import { Users, Clock, AlertTriangle } from "lucide-react";

export default function SellerDashboard() {
  const stats = [
    { name: "Clientes Activos", value: "45", icon: Users, color: "text-green-500" },
    { name: "Vencen este mes", value: "12", icon: Clock, color: "text-yellow-500" },
    { name: "Vencidos", value: "3", icon: AlertTriangle, color: "text-red-500" },
  ];

  return (
    <SellerLayout>
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {stats.map(stat => (
            <div key={stat.name} className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl flex items-center gap-4">
              <div className={`p-4 rounded-full bg-zinc-800 ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-gray-400">{stat.name}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold">Clientes Recientes</h3>
            <button className="text-sm text-green-500 hover:underline">Ver todos</button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-zinc-800 text-gray-400 text-sm">
                  <th className="pb-3 font-medium">Email</th>
                  <th className="pb-3 font-medium">Estado</th>
                  <th className="pb-3 font-medium">Vencimiento</th>
                  <th className="pb-3 font-medium text-right">Acción</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {[1,2,3].map(i => (
                  <tr key={i} className="border-b border-zinc-800 last:border-0 hover:bg-zinc-800/50">
                    <td className="py-4 py-3 text-gray-200">cliente{i}@gmail.com</td>
                    <td className="py-3">
                      <span className="px-2 py-1 bg-green-500/20 text-green-500 text-xs rounded border border-green-500/20">Activo</span>
                    </td>
                    <td className="py-3 text-gray-400">15 Oct 2024</td>
                    <td className="py-3 text-right">
                      <button className="text-green-500 hover:text-green-400">Renovar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </SellerLayout>
  );
}
