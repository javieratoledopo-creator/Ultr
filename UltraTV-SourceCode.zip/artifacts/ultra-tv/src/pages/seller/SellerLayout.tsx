import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, Users, UserPlus, LogOut } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function SellerLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { logout, userDoc } = useAuth();

  if (userDoc && userDoc.role !== 'seller' && userDoc.role !== 'admin') {
    return <div className="p-8 text-center text-white">Acceso denegado.</div>;
  }

  const menu = [
    { name: "Dashboard", path: "/seller", icon: LayoutDashboard },
    { name: "Mis Clientes", path: "/seller/users", icon: Users },
    { name: "Crear Cuenta", path: "/seller/users/new", icon: UserPlus },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex text-white font-sans">
      <aside className="w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col hidden md:flex">
        <div className="p-6 border-b border-zinc-800">
          <img src="/assets/ultra-tv-logo.png" alt="Ultra TV" className="h-8" />
          <span className="text-xs text-green-500 font-bold tracking-widest uppercase mt-2 block">Vendedor Panel</span>
        </div>
        
        <nav className="flex-1 py-6 px-3 flex flex-col gap-2">
          {menu.map(item => {
            const Icon = item.icon;
            const isActive = location === item.path;
            return (
              <Link 
                key={item.path} 
                href={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-md transition-colors ${
                  isActive ? "bg-green-600 text-white font-medium" : "text-gray-400 hover:bg-zinc-800 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.name}
              </Link>
            )
          })}
        </nav>

        <div className="p-6 border-t border-zinc-800">
          <button 
            onClick={logout}
            className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors w-full"
          >
            <LogOut className="w-5 h-5" />
            Cerrar sesión
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-8 bg-zinc-900/50 backdrop-blur">
          <h2 className="font-semibold text-lg text-gray-200">
            {menu.find(m => location === m.path)?.name || "Panel"}
          </h2>
        </header>
        <div className="flex-1 overflow-auto p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
