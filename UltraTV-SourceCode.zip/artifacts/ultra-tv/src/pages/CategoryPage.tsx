import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import HeroSlider from "@/components/HeroSlider";
import ContentRow from "@/components/ContentRow";
import { tmdb } from "@/lib/tmdb";
import { useTVNavigation } from "@/hooks/useTVNavigation";

interface CategoryPageProps {
  type: 'movie' | 'tv';
}

export default function CategoryPage({ type }: CategoryPageProps) {
  const [heroItems, setHeroItems] = useState([]);
  const [popular, setPopular] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [action, setAction] = useState([]);
  const [comedy, setComedy] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useTVNavigation(); 

  useEffect(() => {
    async function loadData() {
      try {
        const [
          popularRes, 
          topRatedRes, 
          actionRes, 
          comedyRes
        ] = await Promise.all([
          tmdb.fetchPopular(type),
          tmdb.fetchTopRated(type),
          tmdb.fetchByGenre(28, type),
          tmdb.fetchByGenre(35, type)
        ]);

        if (popularRes?.results) {
          const formatted = popularRes.results.map((i:any)=>({...i, type: type === 'tv' ? 'series' : 'movie'}));
          setPopular(formatted);
          const top5 = formatted.slice(0, 5).map((item: any) => ({
            id: item.id,
            type: item.type,
            title: item.title || item.name,
            overview: item.overview,
            backdropUrl: `https://image.tmdb.org/t/p/original${item.backdrop_path}`,
            quality: 'HD',
            year: item.release_date ? new Date(item.release_date).getFullYear() : (item.first_air_date ? new Date(item.first_air_date).getFullYear() : null)
          }));
          setHeroItems(top5);
        }
        
        if (topRatedRes?.results) setTopRated(topRatedRes.results.map((i:any)=>({...i, type: type === 'tv' ? 'series' : 'movie'})));
        if (actionRes?.results) setAction(actionRes.results.map((i:any)=>({...i, type: type === 'tv' ? 'series' : 'movie'})));
        if (comedyRes?.results) setComedy(comedyRes.results.map((i:any)=>({...i, type: type === 'tv' ? 'series' : 'movie'})));

      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [type]);

  if (loading) return <div className="min-h-screen bg-background animate-pulse" />;

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      <HeroSlider items={heroItems} />
      
      <div className="-mt-16 md:-mt-32 relative z-20 flex flex-col gap-6 md:gap-12">
        <ContentRow title="Populares" items={popular} />
        <ContentRow title="Mejor Valoradas" items={topRated} />
        <ContentRow title="Acción y Aventura" items={action} />
        <ContentRow title="Comedia" items={comedy} />
      </div>
    </div>
  );
}
