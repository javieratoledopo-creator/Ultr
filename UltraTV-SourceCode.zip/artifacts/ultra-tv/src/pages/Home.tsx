import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import HeroSlider from "@/components/HeroSlider";
import ContentRow from "@/components/ContentRow";
import { tmdb } from "@/lib/tmdb";
import { useTVNavigation } from "@/hooks/useTVNavigation";

export default function Home() {
  const [trending, setTrending] = useState([]);
  const [movies, setMovies] = useState([]);
  const [series, setSeries] = useState([]);
  const [action, setAction] = useState([]);
  const [comedy, setComedy] = useState([]);
  const [heroItems, setHeroItems] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useTVNavigation(); // Enable TV controls on this page

  useEffect(() => {
    async function loadData() {
      try {
        const [
          trendingRes, 
          moviesRes, 
          seriesRes, 
          actionRes, 
          comedyRes
        ] = await Promise.all([
          tmdb.fetchTrending('all', 'week'),
          tmdb.fetchPopular('movie'),
          tmdb.fetchPopular('tv'),
          tmdb.fetchByGenre(28, 'movie'),
          tmdb.fetchByGenre(35, 'movie')
        ]);

        if (trendingRes?.results) {
          setTrending(trendingRes.results);
          // For Hero Slider, map top 5 trending items
          const top5 = trendingRes.results.slice(0, 5).map((item: any) => ({
            id: item.id,
            type: item.media_type || (item.name ? 'series' : 'movie'),
            title: item.title || item.name,
            overview: item.overview,
            backdropUrl: `https://image.tmdb.org/t/p/original${item.backdrop_path}`,
            quality: '4K',
            year: item.release_date ? new Date(item.release_date).getFullYear() : (item.first_air_date ? new Date(item.first_air_date).getFullYear() : null)
          }));
          setHeroItems(top5);
        }
        
        if (moviesRes?.results) setMovies(moviesRes.results.map((i:any)=>({...i, type: 'movie'})));
        if (seriesRes?.results) setSeries(seriesRes.results.map((i:any)=>({...i, type: 'series'})));
        if (actionRes?.results) setAction(actionRes.results.map((i:any)=>({...i, type: 'movie'})));
        if (comedyRes?.results) setComedy(comedyRes.results.map((i:any)=>({...i, type: 'movie'})));

      } catch (error) {
        console.error("Failed to load home data", error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  if (loading) {
    return <div className="min-h-screen bg-background animate-pulse" />;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      <HeroSlider items={heroItems} />
      
      <div className="-mt-16 md:-mt-32 relative z-20 flex flex-col gap-6 md:gap-12">
        <ContentRow title="Tendencias" items={trending} />
        <ContentRow title="Películas Populares" items={movies} />
        <ContentRow title="Series Aclamadas" items={series} />
        <ContentRow title="Acción y Aventura" items={action} />
        <ContentRow title="Comedias para no parar de reir" items={comedy} />
      </div>
    </div>
  );
}
