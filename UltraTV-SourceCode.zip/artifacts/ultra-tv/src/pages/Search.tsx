import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import { tmdb } from "@/lib/tmdb";
import { Search as SearchIcon } from "lucide-react";
import ContentCard from "@/components/ContentCard";
import { useTVNavigation } from "@/hooks/useTVNavigation";
import { useDeviceType } from "@/hooks/useDeviceType";

export default function Search() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const { isTV } = useDeviceType();
  useTVNavigation();

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (query.trim().length > 2) {
        setLoading(true);
        try {
          const res = await tmdb.searchContent(query);
          if (res?.results) {
            // Filter out people, keep only movies and series
            setResults(res.results.filter((item: any) => item.media_type !== 'person'));
          }
        } finally {
          setLoading(false);
        }
      } else {
        setResults([]);
      }
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className={`pt-24 md:pt-32 px-4 md:px-12 max-w-7xl mx-auto ${isTV ? "pt-40" : ""}`}>
        <div className="relative mb-12">
          <SearchIcon className={`absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 ${isTV ? "w-8 h-8" : "w-6 h-6"}`} />
          <input
            type="text"
            placeholder="Películas, programas de TV..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className={`w-full bg-zinc-900 border border-zinc-700 text-white placeholder:text-gray-500 rounded-md focus:border-white focus:ring-1 focus:ring-white transition-all outline-none pl-14
              ${isTV ? "h-20 text-2xl" : "h-14 text-lg"}
            `}
            autoFocus
            data-tv-focusable="true"
          />
        </div>

        {loading ? (
          <div className="flex justify-center mt-20">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div>
            {query.length > 2 && results.length === 0 ? (
              <p className="text-gray-400 text-center text-xl mt-20">No se encontraron resultados para "{query}"</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6 pb-20">
                {results.map((item: any) => (
                  <ContentCard
                    key={item.id}
                    id={item.id}
                    type={item.media_type || (item.name ? 'series' : 'movie')}
                    title={item.title || item.name}
                    posterUrl={`https://image.tmdb.org/t/p/w500${item.poster_path}`}
                    rating={item.vote_average}
                    year={item.release_date ? new Date(item.release_date).getFullYear() : (item.first_air_date ? new Date(item.first_air_date).getFullYear() : undefined)}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
