import { useEffect, useRef } from 'react';

export function useTVNavigation() {
  const containerRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    // Only enable if we are in TV mode (checking body class from useDeviceType)
    if (!document.body.classList.contains('tv-mode')) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const focusables = Array.from(
        document.querySelectorAll<HTMLElement>('[data-tv-focusable="true"]')
      );
      
      if (focusables.length === 0) return;

      const currentIndex = focusables.findIndex(el => el === document.activeElement);

      let nextIndex = currentIndex;

      switch (e.key) {
        case 'ArrowRight':
          nextIndex = currentIndex + 1 >= focusables.length ? 0 : currentIndex + 1;
          e.preventDefault();
          break;
        case 'ArrowLeft':
          nextIndex = currentIndex - 1 < 0 ? focusables.length - 1 : currentIndex - 1;
          e.preventDefault();
          break;
        case 'ArrowDown':
          // Simplified 2D logic: jump by an estimated row length. For a real app,
          // spatial navigation libraries (like LRUD) are preferred.
          nextIndex = Math.min(currentIndex + 4, focusables.length - 1);
          e.preventDefault();
          break;
        case 'ArrowUp':
          nextIndex = Math.max(currentIndex - 4, 0);
          e.preventDefault();
          break;
        case 'Enter':
          if (document.activeElement instanceof HTMLElement) {
            document.activeElement.click();
          }
          break;
      }

      if (nextIndex !== currentIndex && focusables[nextIndex]) {
        focusables[nextIndex].focus();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return containerRef;
}
