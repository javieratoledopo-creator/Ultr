import { useState, useEffect } from 'react';

export function useDeviceType() {
  const [deviceType, setDeviceType] = useState({
    isTV: false,
    isMobile: false,
    isTablet: false,
  });

  useEffect(() => {
    const userAgent = navigator.userAgent.toLowerCase();
    const isTVUserAgent = /tv|smarttv|googletv|appletv|hbbtv|p002|netcast|viera|bravia|tizen|webos/i.test(userAgent);
    const width = window.innerWidth;
    
    // On a real device or when pretending to be TV (width > 1280 and no touch)
    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    const isTV = isTVUserAgent || (width >= 1280 && !isTouch);
    const isMobile = width < 768;
    const isTablet = width >= 768 && width < 1280 && isTouch;

    setDeviceType({ isTV, isMobile, isTablet });
    
    if (isTV) {
      document.body.classList.add('tv-mode');
    } else {
      document.body.classList.remove('tv-mode');
    }
  }, []);

  return deviceType;
}
