const TMDB_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJiNThhYWY1ZDk1NGY5Y2Q4MjRkNjQ0N2Y5ZmQzMjU5MiIsIm5iZiI6MTc4Mjc3MTc5Ny4yMDQsInN1YiI6IjZhND";
const BASE_URL = "https://api.themoviedb.org/3";

const headers = {
  Authorization: `Bearer ${TMDB_TOKEN}`,
  accept: "application/json",
};

async function fetchFromTMDB(endpoint: string, params: Record<string, string | number> = {}) {
  const url = new URL(`${BASE_URL}${endpoint}`);
  url.searchParams.append('language', 'es-ES'); // Spanish content by default for Netflix LATAM feel
  
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.append(key, value.toString());
  });

  try {
    const res = await fetch(url.toString(), { headers });
    if (!res.ok) throw new Error(`TMDB error: ${res.statusText}`);
    return await res.json();
  } catch (error) {
    console.error(`Error fetching TMDB endpoint ${endpoint}:`, error);
    return null;
  }
}

export const getBackdropUrl = (path: string, size: 'w780' | 'w1280' | 'original' = 'w1280') => 
  path ? `https://image.tmdb.org/t/p/${size}${path}` : '';

export const getPosterUrl = (path: string, size: 'w342' | 'w500' | 'w780' = 'w500') => 
  path ? `https://image.tmdb.org/t/p/${size}${path}` : '';

export const getLogoUrl = (path: string) => 
  path ? `https://image.tmdb.org/t/p/w500${path}` : '';

export const tmdb = {
  fetchTrending: async (type: 'movie' | 'tv' | 'all' = 'all', timeWindow: 'day' | 'week' = 'week') => 
    fetchFromTMDB(`/trending/${type}/${timeWindow}`),
    
  fetchNowPlaying: async () => fetchFromTMDB('/movie/now_playing'),
  
  fetchPopular: async (type: 'movie' | 'tv' = 'movie') => fetchFromTMDB(`/${type}/popular`),
  
  fetchTopRated: async (type: 'movie' | 'tv' = 'movie') => fetchFromTMDB(`/${type}/top_rated`),
  
  fetchByGenre: async (genreId: number, type: 'movie' | 'tv' = 'movie') => 
    fetchFromTMDB(`/discover/${type}`, { with_genres: genreId }),
    
  searchContent: async (query: string) => 
    fetchFromTMDB('/search/multi', { query }),
    
  fetchDetails: async (id: number, type: 'movie' | 'tv' = 'movie') => 
    fetchFromTMDB(`/${type}/${id}`, { append_to_response: 'credits,videos,recommendations,similar,images' }),
    
  fetchSeasons: async (seriesId: number, seasonNumber: number) => 
    fetchFromTMDB(`/tv/${seriesId}/season/${seasonNumber}`),
    
  fetchEpisodes: async (seriesId: number, seasonNumber: number) => 
    fetchFromTMDB(`/tv/${seriesId}/season/${seasonNumber}`) // Same endpoint returns episodes
};
