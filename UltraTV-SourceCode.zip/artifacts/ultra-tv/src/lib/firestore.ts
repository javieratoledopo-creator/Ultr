import { Timestamp } from "firebase/firestore";

export type Role = 'admin' | 'seller' | 'user';

export interface Profile {
  id: string;
  name: string;
  avatarIndex: number;
  watchHistory: {
    contentId: string;
    contentType: 'movie' | 'tv';
    progress: number;
    episodeId?: string;
    updatedAt: Timestamp;
  }[];
  favorites: {
    contentId: string;
    contentType: 'movie' | 'tv';
    addedAt: Timestamp;
  }[];
  myList: {
    contentId: string;
    contentType: 'movie' | 'tv';
    addedAt: Timestamp;
  }[];
}

export interface UserDoc {
  uid: string;
  email: string;
  role: Role;
  createdBy?: string;
  expiresAt?: Timestamp;
  active: boolean;
  profiles: Profile[];
  activeProfileId?: string;
  createdAt: Timestamp;
}

export interface Season {
  id: string;
  seasonNumber: number;
  name: string;
  overview: string;
  posterPath: string;
  episodes: Episode[];
}

export interface Episode {
  id: string;
  episodeNumber: number;
  name: string;
  overview: string;
  stillPath: string;
  duration: number;
  streamUrl: string;
  airDate: string;
}

export interface Content {
  id: string;
  tmdbId: number;
  type: 'movie' | 'series';
  title: string;
  overview: string;
  posterPath: string;
  backdropPath: string;
  logoPath?: string;
  year: number;
  rating: number;
  quality: 'HD' | 'FHD' | '4K';
  genres: string[];
  featured: boolean;
  heroSliderEnabled: boolean;
  streamUrl?: string;
  trailer?: string;
  cast: { name: string; character: string; profilePath: string }[];
  director?: string;
  duration?: number;
  seasons?: Season[];
  category: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface IptvChannel {
  id: string;
  name: string;
  category: string;
  logoUrl: string;
  streamUrl: string;
  active: boolean;
}

export interface Category {
  id: string;
  name: string;
  order: number;
  active: boolean;
}

export interface Seller {
  uid: string;
  email: string;
  name: string;
  createdBy: string;
  active: boolean;
  totalSales: number;
  createdAt: Timestamp;
}
