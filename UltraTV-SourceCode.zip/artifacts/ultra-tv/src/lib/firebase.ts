import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyCLLSijfHCArQ7jAC7IVyW8W4HaAscWfuo",
  authDomain: "oktf-38850.firebaseapp.com",
  projectId: "oktf-38850",
  storageBucket: "oktf-38850.firebasestorage.app",
  messagingSenderId: "129919125300",
  appId: "1:129919125300:web:9f403830862b42d72c8761",
  measurementId: "G-T5FT0B2L9R"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const analytics = typeof window !== "undefined" ? getAnalytics(app) : null;
