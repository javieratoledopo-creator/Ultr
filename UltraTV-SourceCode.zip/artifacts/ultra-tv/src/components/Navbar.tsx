import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, Bell, Menu } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useDeviceType } from "@/hooks/useDeviceType";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { userDoc, activeProfile, logout } = useAuth();
  const { isTV, isMobile } = useDeviceType();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Inicio", path: "/home" },
    { name: "Películas", path: "/movies" },
    { name: "Series", path: "/series" },
    { name: "IPTV", path: "/iptv" },
    { name: "Mi Lista", path: "/my-list" }
  ];

  return (
    <>
      <nav
        className={`fixed top-0 w-full z-50 transition-colors duration-300 ${
          isScrolled ? "bg-background shadow-lg shadow-black/50" : "bg-gradient-to-b from-black/80 to-transparent"
        } ${isTV ? "py-6 px-12" : "py-4 px-4 md:px-8"}`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/home" className="flex-shrink-0" data-tv-focusable="true">
              <img src="/assets/ultra-tv-logo.png" alt="Ultra TV" className={isTV ? "h-12" : "h-8"} />
            </Link>
            
            {!isMobile && (
              <div className="hidden md:flex items-center gap-6">
                {navLinks.map((link) => (
                  <Link 
                    key={link.name} 
                    href={link.path}
                    className={`text-sm font-medium transition-colors hover:text-primary ${isTV ? "text-lg" : "text-gray-300"}`}
                    data-tv-focusable="true"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-4 md:gap-6">
            <button 
              onClick={() => setLocation("/search")}
              className="text-white hover:text-primary transition-colors"
              data-tv-focusable="true"
            >
              <Search className={isTV ? "w-8 h-8" : "w-5 h-5"} />
            </button>

            {isMobile && (
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-white"
              >
                <Menu className="w-6 h-6" />
              </button>
            )}

            {!isMobile && (
              <div className="group relative">
                <button 
                  className="flex items-center gap-2 outline-none focus:ring-2 focus:ring-primary rounded"
                  data-tv-focusable="true"
                >
                  <img 
                    src={`/assets/avatar-${(activeProfile?.avatarIndex || 0) + 1}.jpg`} 
                    alt="Profile" 
                    className={`${isTV ? "w-12 h-12" : "w-8 h-8"} rounded shadow border border-transparent group-hover:border-white transition-all object-cover`}
                  />
                </button>
                <div className="absolute right-0 top-full mt-2 w-48 bg-black/90 border border-border rounded-md shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <div className="p-4 flex flex-col gap-3">
                    <div className="flex items-center gap-3 border-b border-border pb-3">
                      <img 
                        src={`/assets/avatar-${(activeProfile?.avatarIndex || 0) + 1}.jpg`} 
                        alt="Profile" 
                        className="w-8 h-8 rounded object-cover"
                      />
                      <span className="text-sm font-medium">{activeProfile?.name}</span>
                    </div>
                    <Link href="/profiles" className="text-sm text-gray-300 hover:text-white" data-tv-focusable="true">Cambiar de perfil</Link>
                    {userDoc?.role === 'admin' && (
                      <Link href="/admin" className="text-sm text-primary hover:text-white" data-tv-focusable="true">Panel de Admin</Link>
                    )}
                    {userDoc?.role === 'seller' && (
                      <Link href="/seller" className="text-sm text-primary hover:text-white" data-tv-focusable="true">Panel de Vendedor</Link>
                    )}
                    <button onClick={logout} className="text-sm text-gray-300 hover:text-white text-left" data-tv-focusable="true">Cerrar sesión</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col p-6 animate-in slide-in-from-right">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center gap-3">
              <img 
                src={`/assets/avatar-${(activeProfile?.avatarIndex || 0) + 1}.jpg`} 
                alt="Profile" 
                className="w-10 h-10 rounded object-cover"
              />
              <span className="font-bold text-lg">{activeProfile?.name}</span>
            </div>
            <button onClick={() => setIsMobileMenuOpen(false)} className="text-white text-2xl font-light">&times;</button>
          </div>
          <div className="flex flex-col gap-6 text-xl">
            {navLinks.map((link) => (
              <button 
                key={link.name} 
                onClick={() => {
                  setLocation(link.path);
                  setIsMobileMenuOpen(false);
                }}
                className="text-left font-medium text-gray-300 hover:text-white"
              >
                {link.name}
              </button>
            ))}
            <div className="h-px bg-border my-2"></div>
            <button 
              onClick={() => {
                setLocation("/profiles");
                setIsMobileMenuOpen(false);
              }}
              className="text-left font-medium text-gray-300 hover:text-white"
            >
              Cambiar de perfil
            </button>
            {userDoc?.role === 'admin' && (
              <button 
                onClick={() => { setLocation("/admin"); setIsMobileMenuOpen(false); }}
                className="text-left font-medium text-primary hover:text-white"
              >
                Panel de Admin
              </button>
            )}
            {userDoc?.role === 'seller' && (
              <button 
                onClick={() => { setLocation("/seller"); setIsMobileMenuOpen(false); }}
                className="text-left font-medium text-primary hover:text-white"
              >
                Panel de Vendedor
              </button>
            )}
            <button onClick={logout} className="text-left font-medium text-gray-300 hover:text-white">Cerrar sesión</button>
          </div>
        </div>
      )}
    </>
  );
}
