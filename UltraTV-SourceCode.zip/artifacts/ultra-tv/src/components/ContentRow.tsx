import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import ContentCard from "./ContentCard";
import { useDeviceType } from "@/hooks/useDeviceType";

interface ContentRowProps {
  title: string;
  items: any[];
}

export default function ContentRow({ title, items }: ContentRowProps) {
  const rowRef = useRef<HTMLDivElement>(null);
  const { isTV, isMobile } = useDeviceType();

  const scroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth + 100 : scrollLeft + clientWidth - 100;
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className={`relative ${isTV ? "mb-12" : "mb-8"}`}>
      <h2 className={`font-bold text-white mb-4 px-4 md:px-8 ${isTV ? "text-2xl" : "text-lg md:text-xl"}`}>
        {title}
      </h2>
      
      <div className="group relative">
        {!isMobile && (
          <button 
            className="absolute left-0 top-0 bottom-0 z-40 w-12 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center hover:bg-black/80"
            onClick={() => scroll('left')}
            tabIndex={-1}
          >
            <ChevronLeft className="w-8 h-8 text-white" />
          </button>
        )}

        <div 
          ref={rowRef}
          className="flex gap-2 md:gap-4 overflow-x-auto scrollbar-hide px-4 md:px-8 pb-4 pt-4 -mt-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {items.map((item, i) => (
            <ContentCard 
              key={`${item.id}-${i}`}
              id={item.id}
              type={item.type || 'movie'}
              title={item.title || item.name}
              posterUrl={item.posterUrl || `https://image.tmdb.org/t/p/w500${item.poster_path}`}
              rating={item.vote_average || item.rating}
              year={item.release_date ? new Date(item.release_date).getFullYear() : item.year}
              quality={item.quality || 'HD'}
            />
          ))}
        </div>

        {!isMobile && (
          <button 
            className="absolute right-0 top-0 bottom-0 z-40 w-12 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center hover:bg-black/80"
            onClick={() => scroll('right')}
            tabIndex={-1}
          >
            <ChevronRight className="w-8 h-8 text-white" />
          </button>
        )}
      </div>
    </div>
  );
}
