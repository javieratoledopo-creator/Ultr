import { useState } from "react";
import { Link } from "wouter";
import { Play, Plus, Info } from "lucide-react";
import { useDeviceType } from "@/hooks/useDeviceType";

interface ContentCardProps {
  id: string | number;
  type: 'movie' | 'series';
  title: string;
  posterUrl: string;
  rating?: number;
  year?: number;
  quality?: string;
}

export default function ContentCard({ id, type, title, posterUrl, rating, year, quality = 'HD' }: ContentCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const { isTV } = useDeviceType();

  return (
    <Link 
      href={`/content/${id}?type=${type}`}
      className={`relative group flex-shrink-0 cursor-pointer outline-none focus:ring-4 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background rounded-md transition-all duration-300 ease-out 
        ${isTV ? 'w-48 md:w-56' : 'w-32 md:w-48'} 
        ${isHovered ? 'z-20 scale-105 shadow-2xl' : 'z-10'}`
      }
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-tv-focusable="true"
    >
      <div className="aspect-[2/3] bg-card rounded-md overflow-hidden relative">
        <img 
          src={posterUrl} 
          alt={title} 
          className="w-full h-full object-cover"
          loading="lazy"
        />
        
        {quality && (
          <div className="absolute top-2 right-2 bg-primary/90 text-white text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider backdrop-blur-sm shadow-sm">
            {quality}
          </div>
        )}

        <div className={`absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent flex flex-col justify-end p-4 transition-opacity duration-300 ${isHovered || isTV ? 'opacity-100' : 'opacity-0'}`}>
          <h3 className="text-white font-bold text-sm md:text-base leading-tight line-clamp-2 mb-2">{title}</h3>
          
          <div className="flex items-center gap-2 text-xs text-gray-300 font-medium mb-3">
            {year && <span>{year}</span>}
            {rating && (
              <span className="flex items-center text-green-400">
                ★ {rating.toFixed(1)}
              </span>
            )}
          </div>

          {(isHovered || isTV) && (
            <div className="flex items-center gap-2">
              <button className="bg-white text-black p-1.5 rounded-full hover:bg-gray-200 transition-colors flex-1 flex items-center justify-center">
                <Play className="w-4 h-4 fill-current" />
              </button>
              <button className="bg-black/50 border border-gray-500 text-white p-1.5 rounded-full hover:border-white transition-colors">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}
