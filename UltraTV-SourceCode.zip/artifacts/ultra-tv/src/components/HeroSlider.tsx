import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Play, Plus, Info } from "lucide-react";
import { useDeviceType } from "@/hooks/useDeviceType";

interface HeroItem {
  id: string | number;
  type: 'movie' | 'series';
  title: string;
  overview: string;
  backdropUrl: string;
  logoUrl?: string;
  year?: number;
  quality?: string;
}

interface HeroSliderProps {
  items: HeroItem[];
}

export default function HeroSlider({ items }: HeroSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { isTV, isMobile } = useDeviceType();

  useEffect(() => {
    if (!items || items.length <= 1) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % items.length);
    }, 8000); // 8 seconds

    return () => clearInterval(interval);
  }, [items]);

  if (!items || items.length === 0) {
    return <div className="w-full aspect-video md:h-[70vh] lg:h-[85vh] bg-black animate-pulse"></div>;
  }

  const current = items[currentIndex];

  return (
    <div className={`relative w-full ${isTV ? "h-screen" : "h-[60vh] md:h-[80vh]"} overflow-hidden bg-black`}>
      {/* Background Image */}
      {items.map((item, index) => (
        <div
          key={item.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentIndex ? 'opacity-100' : 'opacity-0'}`}
        >
          <img
            src={item.backdropUrl}
            alt={item.title}
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent"></div>
        </div>
      ))}

      {/* Content */}
      <div className={`absolute bottom-0 left-0 w-full p-6 md:p-12 ${isTV ? "pb-24 px-16" : "pb-12"} md:w-2/3 lg:w-1/2 z-10 flex flex-col justify-end h-full`}>
        {current.logoUrl ? (
          <img src={current.logoUrl} alt={current.title} className="w-auto max-w-[80%] md:max-w-[400px] max-h-[150px] object-contain mb-4" />
        ) : (
          <h1 className={`font-black text-white leading-tight mb-4 ${isTV ? "text-6xl" : "text-4xl md:text-5xl lg:text-6xl"}`}>
            {current.title}
          </h1>
        )}

        <div className="flex items-center gap-4 text-sm md:text-base font-semibold text-gray-300 mb-4">
          {current.year && <span>{current.year}</span>}
          {current.quality && (
            <span className="border border-gray-500 px-1.5 py-0.5 rounded text-xs tracking-wider">
              {current.quality}
            </span>
          )}
          <span className="text-green-400 font-bold">98% Coincidencia</span>
        </div>

        <p className={`text-gray-200 text-sm md:text-base lg:text-lg mb-8 line-clamp-3 md:line-clamp-4 max-w-2xl drop-shadow-md ${isTV ? "text-xl line-clamp-3" : ""}`}>
          {current.overview}
        </p>

        <div className="flex items-center gap-3 md:gap-4">
          <Link href={`/player/${current.id}?type=${current.type}`}>
            <button 
              className={`bg-white text-black font-bold flex items-center justify-center gap-2 rounded hover:bg-gray-200 transition-colors outline-none focus:ring-4 focus:ring-primary focus:ring-offset-2 focus:ring-offset-black
                ${isTV ? "py-4 px-8 text-xl" : "py-2 px-6 md:py-3 md:px-8 text-base"}
              `}
              data-tv-focusable="true"
            >
              <Play className={isTV ? "w-6 h-6 fill-current" : "w-5 h-5 fill-current"} />
              Ver Ahora
            </button>
          </Link>
          
          <Link href={`/content/${current.id}?type=${current.type}`}>
            <button 
              className={`bg-gray-500/50 backdrop-blur-sm text-white font-semibold flex items-center justify-center gap-2 rounded hover:bg-gray-500/70 transition-colors outline-none focus:ring-4 focus:ring-primary focus:ring-offset-2 focus:ring-offset-black
                ${isTV ? "py-4 px-8 text-xl" : "py-2 px-6 md:py-3 md:px-8 text-base"}
              `}
              data-tv-focusable="true"
            >
              <Info className={isTV ? "w-6 h-6" : "w-5 h-5"} />
              Más Info
            </button>
          </Link>
        </div>
      </div>

      {/* Dots Indicator */}
      {!isMobile && (
        <div className="absolute bottom-4 right-8 z-10 flex gap-2">
          {items.map((_, idx) => (
            <button
              key={idx}
              className={`w-2 h-2 rounded-full transition-all ${idx === currentIndex ? "w-6 bg-white" : "bg-white/50 hover:bg-white/80"}`}
              onClick={() => setCurrentIndex(idx)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
