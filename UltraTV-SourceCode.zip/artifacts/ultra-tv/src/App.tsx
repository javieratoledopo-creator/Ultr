import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';

import Splash from '@/pages/Splash';
import Login from '@/pages/Login';
import Profiles from '@/pages/Profiles';
import Home from '@/pages/Home';
import Search from '@/pages/Search';
import ContentDetail from '@/pages/ContentDetail';
import Player from '@/pages/Player';
import CategoryPage from '@/pages/CategoryPage';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import SellerDashboard from '@/pages/seller/SellerDashboard';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

// Protected Route Wrapper
const ProtectedRoute = ({ component: Component, ...rest }: any) => {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) return <div className="min-h-screen bg-black" />;
  if (!user) {
    setLocation('/login');
    return null;
  }
  return <Component {...rest} />;
};

function Router() {
  return (
    <Switch>
      <Route path="/" component={Splash} />
      <Route path="/login" component={Login} />
      <Route path="/profiles">
        {(params) => <ProtectedRoute component={Profiles} />}
      </Route>
      <Route path="/home">
        {(params) => <ProtectedRoute component={Home} />}
      </Route>
      <Route path="/movies">
        {(params) => <ProtectedRoute component={CategoryPage} type="movie" />}
      </Route>
      <Route path="/series">
        {(params) => <ProtectedRoute component={CategoryPage} type="tv" />}
      </Route>
      <Route path="/search">
        {(params) => <ProtectedRoute component={Search} />}
      </Route>
      <Route path="/content/:id">
        {(params) => <ProtectedRoute component={ContentDetail} id={params.id} />}
      </Route>
      <Route path="/player/:id">
        {(params) => <ProtectedRoute component={Player} id={params.id} type={new URLSearchParams(window.location.search).get('type') || 'movie'} />}
      </Route>
      <Route path="/admin">
        {(params) => <ProtectedRoute component={AdminDashboard} />}
      </Route>
      <Route path="/seller">
        {(params) => <ProtectedRoute component={SellerDashboard} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
