import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { auth, db } from "@/lib/firebase";
import { User, onAuthStateChanged, signOut as firebaseLogout } from "firebase/auth";
import { doc, getDoc, setDoc, Timestamp } from "firebase/firestore";
import { UserDoc, Profile } from "@/lib/firestore";
import { useLocation } from "wouter";

interface AuthContextType {
  user: User | null;
  userDoc: UserDoc | null;
  activeProfile: Profile | null;
  setActiveProfile: (profile: Profile | null) => void;
  loading: boolean;
  logout: () => Promise<void>;
  isAdmin: boolean;
  isSeller: boolean;
  isUser: boolean;
  refreshUserDoc: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userDoc, setUserDoc] = useState<UserDoc | null>(null);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [, setLocation] = useLocation();

  const fetchUserDoc = async (uid: string) => {
    try {
      const docRef = doc(db, "users", uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as UserDoc;
        setUserDoc(data);
        if (data.activeProfileId) {
          const profile = data.profiles.find(p => p.id === data.activeProfileId);
          setActiveProfile(profile || null);
        }
        return data;
      }
    } catch (error) {
      console.error("Error fetching user doc:", error);
    }
    return null;
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        const data = await fetchUserDoc(currentUser.uid);
        
        // Initial Admin Setup:
        if (!data && currentUser.email === "administrador@gmail.com") {
          const newAdminDoc: UserDoc = {
            uid: currentUser.uid,
            email: currentUser.email,
            role: "admin",
            active: true,
            profiles: [{
              id: "admin-profile-1",
              name: "Admin",
              avatarIndex: 0,
              watchHistory: [],
              favorites: [],
              myList: []
            }],
            createdAt: Timestamp.now()
          };
          await setDoc(doc(db, "users", currentUser.uid), newAdminDoc);
          setUserDoc(newAdminDoc);
        }
      } else {
        setUser(null);
        setUserDoc(null);
        setActiveProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const logout = async () => {
    await firebaseLogout(auth);
    setUser(null);
    setUserDoc(null);
    setActiveProfile(null);
    setLocation("/login");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userDoc,
        activeProfile,
        setActiveProfile,
        loading,
        logout,
        isAdmin: userDoc?.role === "admin",
        isSeller: userDoc?.role === "seller",
        isUser: userDoc?.role === "user",
        refreshUserDoc: async () => {
          if (user) await fetchUserDoc(user.uid);
        }
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
